import javax.swing.*;
import java.awt.geom.RoundRectangle2D;

public class Main {

    public static void main(String[] args) {
        System.setProperty("apple.laf.useScreenMenuBar", "true");
        System.setProperty("apple.awt.application.name", "K-Queue");

        SwingUtilities.invokeLater(() -> {
            KitchenApp app = new KitchenApp();
            app.setVisible(true);
        });
    }

    static class KitchenApp extends JFrame {

        private Settings settings = new Settings();
        private JLayeredPane layered;

        public KitchenApp() {
            setTitle("K-Queue — Kitchen Food Order Management System");
            setSize(1280, 720);
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setLocationRelativeTo(null);
            setUndecorated(true);
            setShape(new RoundRectangle2D.Double(0, 0, 1280, 720, 40, 40));

            Database.initialize();

            // Use a layered pane as the base so confetti can float on top
            layered = new JLayeredPane();
            layered.setLayout(null);
            layered.setBounds(0, 0, 1280, 720);
            setContentPane(layered);

            showSplashScreen();
        }

        public void showSplashScreen() {
            SplashScreen splash = new SplashScreen(this, settings);
            splash.setBounds(0, 0, 1280, 720);
            setContent(splash);
        }

        public void showLoginScreen() {
            LoginPanel login = new LoginPanel(this, settings);
            login.setBounds(0, 0, 1280, 720);
            setContent(login);
        }

        public void showDashboard(String username) {
            DashboardPanel dashboard = new DashboardPanel(this, settings, username);
            dashboard.setBounds(0, 0, 1280, 720);
            setContent(dashboard);
        }

        /** Replaces the base content, keeping the layered pane intact. */
        private void setContent(JPanel panel) {
            layered.removeAll();
            layered.add(panel, JLayeredPane.DEFAULT_LAYER);
            layered.revalidate();
            layered.repaint();
        }

        public JLayeredPane getLayered() {
            return layered;
        }
    }
}