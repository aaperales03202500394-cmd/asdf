import java.awt.Color;
import java.util.Random;

public class ConfettiParticle {
    public double x, y;
    public double vx, vy;
    public float alpha = 1.0f;
    public Color color;

    public ConfettiParticle(int originX, int originY, Random rand) {
        this.x = originX;
        this.y = originY;
        double angle = rand.nextDouble() * 2 * Math.PI;
        double speed = 1 + rand.nextDouble() * 3;
        this.vx = Math.cos(angle) * speed;
        this.vy = Math.sin(angle) * speed - 1;
        this.color = new Color(
                rand.nextInt(255),
                rand.nextInt(255),
                rand.nextInt(255),
                255);
    }

    public void update() {
        x += vx;
        y += vy;
        vy += 0.15;         // gravity
        vx *= 0.99;
        alpha -= 0.015f;
        if (alpha < 0) alpha = 0;
        int a = (int) (alpha * 255);
        color = new Color(color.getRed(), color.getGreen(), color.getBlue(), Math.max(0, a));
    }
}