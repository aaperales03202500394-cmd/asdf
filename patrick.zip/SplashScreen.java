import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Random;

public class SplashScreen extends JPanel {

    private final Main.KitchenApp app;
    private final Settings settings;

    private float fadeAlpha = 0f;          // fade in
    private float fadeOutAlpha = 0f;       // fade out
    private boolean fadingOut = false;
    private double logoFloat = 0;
    private int progress = 0;              // 0..100
    private Timer animTimer;
    private Timer progressTimer;
    private final java.util.List<Star> stars = new java.util.ArrayList<>();
    private final Random rand = new Random();

    private final Color WOOD_DARK = new Color(38, 22, 14);
    private final Color WOOD_MID  = new Color(62, 38, 24);
    private final Color AMBER     = new Color(230, 160, 60);
    private final Color CREAM     = new Color(245, 232, 210);

    class Star {
        double x, y, size, speed;
        float alpha;
        Star(int w, int h) {
            x = rand.nextInt(w);
            y = rand.nextInt(h);
            size = 1 + rand.nextDouble() * 2;
            speed = 0.2 + rand.nextDouble() * 0.5;
            alpha = (float) (0.3 + rand.nextDouble() * 0.6);
        }
    }

    public SplashScreen(Main.KitchenApp app, Settings settings) {
        this.app = app;
        this.settings = settings;
        setLayout(null);
        setBackground(WOOD_DARK);
        setOpaque(true);

        for (int i = 0; i < 80; i++) stars.add(new Star(1280, 720));

        // Animation loop
        animTimer = new Timer(16, e -> {
            logoFloat += 0.04;
            if (fadingOut) {
                fadeOutAlpha = Math.min(1f, fadeOutAlpha + 0.04f);
            } else {
                fadeAlpha = Math.min(1f, fadeAlpha + 0.03f);
            }
            for (Star s : stars) {
                s.y += s.speed;
                if (s.y > 720) { s.y = 0; s.x = rand.nextInt(1280); }
            }
            repaint();
            if (fadeOutAlpha >= 1f) {
                animTimer.stop();
                app.showLoginScreen();
            }
        });
        animTimer.start();

        // Progress simulation
        progressTimer = new Timer(30, new ProgressTracker());
        progressTimer.start();
    }

    class ProgressTracker implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            progress += 2 + rand.nextInt(3);
            if (progress >= 100) {
                progress = 100;
                progressTimer.stop();
                // Wait a moment, then fade out
                Timer hold = new Timer(400, ev -> {
                    fadingOut = true;
                    ((Timer) ev.getSource()).stop();
                });
                hold.setRepeats(false);
                hold.start();
            }
            repaint();
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int w = getWidth();
        int h = getHeight();

        // Wood background
        GradientPaint bg = new GradientPaint(0, 0, WOOD_MID, 0, h, WOOD_DARK);
        g2.setPaint(bg);
        g2.fillRect(0, 0, w, h);

        // Planks
        Random plankRand = new Random(99);
        for (int y = 0; y < h; y += 60) {
            int v = plankRand.nextInt(20) - 10;
            Color pc = new Color(clamp(WOOD_MID.getRed() + v),
                    clamp(WOOD_MID.getGreen() + v),
                    clamp(WOOD_MID.getBlue() + v), 120);
            g2.setColor(pc);
            g2.fillRect(0, y, w, 60);
            g2.setColor(new Color(20, 12, 6, 180));
            g2.drawLine(0, y, w, y);
        }

        // Floating stars/embers
        for (Star s : stars) {
            g2.setColor(new Color(1f, 0.85f, 0.6f, s.alpha));
            g2.fillOval((int) s.x, (int) s.y, (int) s.size, (int) s.size);
        }

        // Vignette
        RadialGradientPaint vig = new RadialGradientPaint(
                new Point(w / 2, h / 2),
                Math.max(w, h) * 0.7f,
                new float[]{0.3f, 1.0f},
                new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 180)}
        );
        g2.setPaint(vig);
        g2.fillRect(0, 0, w, h);

        // Fade-in overlay
        if (fadeAlpha < 1f) {
            g2.setColor(new Color(0, 0, 0, (int) ((1 - fadeAlpha) * 255)));
            g2.fillRect(0, 0, w, h);
        }

        // ===== CONTENT =====

        // Emoji ring around logo (subtle)
        String[] emojis = {"🍳", "🍕", "🥗", "🍔", "🍜", "🥘"};
        g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 30));
        for (int i = 0; i < emojis.length; i++) {
            double angle = (System.currentTimeMillis() / 3000.0) + (i * Math.PI * 2 / emojis.length);
            int r = 160;
            int ex = w / 2 + (int) (Math.cos(angle) * r) - 15;
            int ey = h / 2 - 60 + (int) (Math.sin(angle) * r) - 15;
            g2.setColor(new Color(255, 245, 225, 100));
            g2.drawString(emojis[i], ex, ey);
        }

        // Logo text (K-Queue)
        int floatOffset = (int) (Math.sin(logoFloat) * 8);

        // Glow
        for (int i = 10; i > 0; i--) {
            g2.setColor(new Color(230, 160, 60, 4));
            g2.setFont(new Font("Serif", Font.BOLD, 90 + i));
            FontMetrics fm = g2.getFontMetrics();
            String t = "K-Queue";
            int tx = (w - fm.stringWidth(t)) / 2;
            int ty = h / 2 + floatOffset;
            g2.drawString(t, tx, ty);
        }

        // Main text
        g2.setFont(new Font("Serif", Font.BOLD, 90));
        g2.setColor(CREAM);
        FontMetrics fm = g2.getFontMetrics();
        String title = "K-Queue";
        int tx = (w - fm.stringWidth(title)) / 2;
        int ty = h / 2 + floatOffset;
        g2.drawString(title, tx, ty);

        // Subtitle
        g2.setFont(new Font("Arial", Font.PLAIN, 14));
        g2.setColor(new Color(200, 175, 145));
        String subtitle = "Kitchen Food Order Management System";
        FontMetrics fm2 = g2.getFontMetrics();
        int sx = (w - fm2.stringWidth(subtitle)) / 2;
        g2.drawString(subtitle, sx, h / 2 + 40 + floatOffset);

        // Loading bar
        int barW = 300;
        int barH = 6;
        int barX = (w - barW) / 2;
        int barY = h / 2 + 100;

        // Track
        g2.setColor(new Color(255, 255, 255, 40));
        g2.fillRoundRect(barX, barY, barW, barH, barH, barH);

        // Fill
        int fillW = (int) (barW * (progress / 100.0));
        GradientPaint barGrad = new GradientPaint(barX, barY, AMBER,
                barX + barW, barY, new Color(255, 200, 100));
        g2.setPaint(barGrad);
        g2.fillRoundRect(barX, barY, fillW, barH, barH, barH);

        // Percent text
        g2.setFont(new Font("Arial", Font.PLAIN, 11));
        g2.setColor(new Color(200, 175, 145));
        String pct = progress + "%";
        FontMetrics fm3 = g2.getFontMetrics();
        g2.drawString(pct, (w - fm3.stringWidth(pct)) / 2, barY + 30);

        // Fade-out overlay
        if (fadeOutAlpha > 0) {
            g2.setColor(new Color(0, 0, 0, (int) (fadeOutAlpha * 255)));
            g2.fillRect(0, 0, w, h);
        }
    }

    private int clamp(int v) {
        return Math.max(0, Math.min(255, v));
    }
}