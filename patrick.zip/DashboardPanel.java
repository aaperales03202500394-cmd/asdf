import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.*;
import java.util.List;
import java.util.Random;

public class DashboardPanel extends JPanel {

    private final Main.KitchenApp app;
    private final OrderService service = new OrderService();
    private MaxHeap pq;

    private final DefaultTableModel tableModel;
    private final JTable table;
    private final JLabel nextOrderLabel = new JLabel("—");

    private final Point dragOffset = new Point();

    // ==== WOODEN THEME ====
    private final Color WOOD_DARK      = new Color(38, 22, 14);
    private final Color WOOD_MID       = new Color(62, 38, 24);
    private final Color WOOD_LIGHT     = new Color(92, 58, 36);
    private final Color WOOD_GRAIN     = new Color(30, 18, 10);
    private final Color TEXT_CREAM     = new Color(245, 232, 210);
    private final Color TEXT_WARM      = new Color(200, 175, 145);
    private final Color ACCENT_AMBER   = new Color(230, 160, 60);
    private final Color BORDER_WOOD    = new Color(90, 60, 40);

    private static final int SIDEBAR_W = 240;

    public DashboardPanel(Main.KitchenApp app, Settings settings, String username) {
        this.app = app;
        setLayout(null);

        // ==== Background — wooden texture (no image) ====
        JPanel bg = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Wood gradient
                GradientPaint base = new GradientPaint(0, 0, WOOD_MID, 0, h, WOOD_DARK);
                g2.setPaint(base);
                g2.fillRect(0, 0, w, h);

                // Planks
                Random plankRand = new Random(99);
                for (int y = 0; y < h; y += 60) {
                    int v = plankRand.nextInt(20) - 10;
                    Color pc = new Color(
                            clamp(WOOD_MID.getRed() + v),
                            clamp(WOOD_MID.getGreen() + v),
                            clamp(WOOD_MID.getBlue() + v), 120);
                    g2.setColor(pc);
                    g2.fillRect(0, y, w, 60);
                    g2.setColor(new Color(20, 12, 6, 160));
                    g2.drawLine(0, y, w, y);
                }

                // Grain lines
                Random grainRand = new Random(7);
                g2.setStroke(new BasicStroke(0.8f));
                for (int i = 0; i < 260; i++) {
                    int gy = grainRand.nextInt(h);
                    int gx = grainRand.nextInt(w);
                    int len = 40 + grainRand.nextInt(200);
                    g2.setColor(new Color(
                            WOOD_GRAIN.getRed(),
                            WOOD_GRAIN.getGreen(),
                            WOOD_GRAIN.getBlue(),
                            20 + grainRand.nextInt(30)));

                    Path2D.Double p = new Path2D.Double();
                    p.moveTo(gx, gy);
                    int segments = 4;
                    for (int s = 1; s <= segments; s++) {
                        int nx = gx + (len / segments) * s;
                        int ny = gy + grainRand.nextInt(4) - 2;
                        p.lineTo(nx, ny);
                    }
                    g2.draw(p);
                }

                // Knots
                Random knotRand = new Random(3);
                for (int i = 0; i < 4; i++) {
                    int kx = knotRand.nextInt(w);
                    int ky = knotRand.nextInt(h);
                    int kr = 8 + knotRand.nextInt(15);
                    for (int r = kr; r > 0; r -= 2) {
                        g2.setColor(new Color(
                                WOOD_GRAIN.getRed(),
                                WOOD_GRAIN.getGreen(),
                                WOOD_GRAIN.getBlue(),
                                50));
                        g2.drawOval(kx - r / 2, ky - r / 3, r, (int) (r * 0.7));
                    }
                }

                // Vignette
                RadialGradientPaint vignette = new RadialGradientPaint(
                        new Point(w / 2, h / 2),
                        Math.max(w, h) * 0.85f,
                        new float[]{0.3f, 1.0f},
                        new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 160)}
                );
                g2.setPaint(vignette);
                g2.fillRect(0, 0, w, h);
            }
        };
        bg.setBounds(0, 0, 1280, 720);
        add(bg);

        // ==== Drag window ====
        bg.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragOffset.x = e.getX();
                dragOffset.y = e.getY();
            }
        });
        bg.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                if (app.getExtendedState() != JFrame.MAXIMIZED_BOTH) {
                    Point p = app.getLocation();
                    app.setLocation(p.x + e.getX() - dragOffset.x,
                            p.y + e.getY() - dragOffset.y);
                }
            }
        });

        // ================================================================
        // =================== WOODEN SIDEBAR =============================
        // ================================================================
        JPanel sidebar = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                Shape oldClip = g2.getClip();
                RoundRectangle2D sideShape = new RoundRectangle2D.Double(
                        -40, 0, w + 40, h, 40, 40);
                g2.setClip(sideShape);

                // Slightly darker wood so sidebar stands out from bg
                GradientPaint base = new GradientPaint(
                        0, 0, new Color(30, 18, 10),
                        0, h, new Color(18, 10, 5));
                g2.setPaint(base);
                g2.fillRect(-40, 0, w + 40, h);

                // Planks
                Random plankRand = new Random(42);
                for (int y = 0; y < h; y += 60) {
                    int v = plankRand.nextInt(20) - 10;
                    Color pc = new Color(
                            clamp(40 + v),
                            clamp(24 + v),
                            clamp(14 + v), 100);
                    g2.setColor(pc);
                    g2.fillRect(-40, y, w + 40, 60);
                    g2.setColor(new Color(10, 6, 3, 150));
                    g2.drawLine(-40, y, w, y);
                }

                // Grain
                Random grainRand = new Random(5);
                g2.setStroke(new BasicStroke(0.7f));
                for (int i = 0; i < 80; i++) {
                    int gy = grainRand.nextInt(h);
                    int gx = grainRand.nextInt(w);
                    int len = 30 + grainRand.nextInt(150);
                    g2.setColor(new Color(
                            WOOD_GRAIN.getRed(),
                            WOOD_GRAIN.getGreen(),
                            WOOD_GRAIN.getBlue(),
                            25 + grainRand.nextInt(25)));
                    Path2D.Double p = new Path2D.Double();
                    p.moveTo(gx, gy);
                    p.lineTo(gx + len / 2, gy + grainRand.nextInt(3) - 1);
                    p.lineTo(gx + len, gy + grainRand.nextInt(3) - 1);
                    g2.draw(p);
                }

                g2.setClip(oldClip);

                // Right edge highlight
                g2.setColor(new Color(255, 220, 180, 70));
                g2.setStroke(new BasicStroke(1f));
                g2.drawLine(w - 1, 20, w - 1, h - 20);
            }
        };
        sidebar.setOpaque(false);
        sidebar.setBounds(0, 0, SIDEBAR_W, 720);
        bg.add(sidebar);

        // ==== Sidebar brand ====
        JLabel brandIcon = new JLabel("🍳");
        brandIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
        brandIcon.setBounds(25, 30, 40, 40);
        sidebar.add(brandIcon);

        JLabel brandName = new JLabel("K-Queue");
        brandName.setFont(new Font("Serif", Font.BOLD, 24));
        brandName.setForeground(TEXT_CREAM);
        brandName.setBounds(65, 30, 160, 30);
        sidebar.add(brandName);

        JLabel brandSub = new JLabel("Kitchen System");
        brandSub.setFont(new Font("Arial", Font.PLAIN, 11));
        brandSub.setForeground(TEXT_WARM);
        brandSub.setBounds(65, 55, 160, 15);
        sidebar.add(brandSub);

        JPanel divider = new JPanel();
        divider.setBackground(new Color(255, 220, 180, 40));
        divider.setBounds(25, 95, SIDEBAR_W - 50, 1);
        sidebar.add(divider);

        // ==== Nav items ====
        String[][] navItems = {
                {"🏠", "Dashboard"},
                {"📋", "Orders"},
                {"📊", "Report"},
                {"⚙", "Settings"},
                {"🔒", "Privacy"}
        };
        int navY = 130;
        for (int i = 0; i < navItems.length; i++) {
            final String icon = navItems[i][0];
            final String label = navItems[i][1];
            final boolean active = i == 0;
            JPanel item = makeNavItem(icon, label, active);
            item.setBounds(15, navY, SIDEBAR_W - 30, 45);
            sidebar.add(item);
            navY += 55;
        }

        // ==== Logout button ====
        JButton logout = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                boolean hover = getModel().isRollover();
                g2.setColor(hover ? new Color(255, 200, 100, 110) : new Color(255, 220, 180, 40));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(new Color(255, 220, 180, 90));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
                g2.dispose();
            }
        };
        logout.setLayout(null);
        logout.setBounds(25, 630, SIDEBAR_W - 50, 50);
        logout.setContentAreaFilled(false);
        logout.setBorderPainted(false);
        logout.setFocusPainted(false);
        logout.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JLabel logoutIcon = new JLabel("🚪");
        logoutIcon.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
        logoutIcon.setForeground(TEXT_CREAM);
        logoutIcon.setBounds(20, 13, 30, 24);
        logout.add(logoutIcon);

        JLabel logoutText = new JLabel("Logout");
        logoutText.setFont(new Font("Arial", Font.BOLD, 13));
        logoutText.setForeground(TEXT_CREAM);
        logoutText.setBounds(55, 15, 130, 20);
        logout.add(logoutText);

        logout.addActionListener(e -> app.showLoginScreen());
        sidebar.add(logout);

        // ================================================================
        // =================== MAIN CONTENT ===============================
        // ================================================================
        int contentX = SIDEBAR_W + 20;
        int contentW = 1280 - SIDEBAR_W - 40;

        // ==== macOS window controls ====
        JPanel macBox = new JPanel(null);
        macBox.setOpaque(false);
        macBox.setBounds(1165, 25, 85, 20);
        bg.add(macBox);
        macBox.add(makeMacButton(8, 2, new Color(230, 160, 35), new Color(255, 189, 46),
                e -> app.setExtendedState(JFrame.ICONIFIED)));
        macBox.add(makeMacButton(34, 2, new Color(34, 175, 52), new Color(40, 200, 64),
                e -> {
                    if (app.getExtendedState() == JFrame.MAXIMIZED_BOTH)
                        app.setExtendedState(JFrame.NORMAL);
                    else app.setExtendedState(JFrame.MAXIMIZED_BOTH);
                }));
        macBox.add(makeMacButton(60, 2, new Color(255, 74, 74), new Color(255, 95, 87),
                e -> System.exit(0)));

        // ==== Title ====
        JLabel title = new JLabel("Kitchen Dashboard");
        title.setBounds(contentX, 30, 400, 35);
        title.setForeground(TEXT_CREAM);
        title.setFont(new Font("Serif", Font.BOLD, 26));
        bg.add(title);

        JLabel welcome = new JLabel("Welcome back, " + username + " 👋");
        welcome.setBounds(contentX, 62, 400, 20);
        welcome.setForeground(TEXT_WARM);
        welcome.setFont(new Font("Arial", Font.PLAIN, 12));
        bg.add(welcome);

        // ==== Next order glass card ====
        JPanel nextCard = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 220, 180, 30));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(new Color(255, 220, 180, 80));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
        };
        nextCard.setLayout(null);
        nextCard.setOpaque(false);
        nextCard.setBounds(contentX, 100, contentW, 80);
        bg.add(nextCard);

        JLabel nextTitle = new JLabel("🔔 Next Order to Prepare");
        nextTitle.setBounds(25, 10, 400, 25);
        nextTitle.setForeground(ACCENT_AMBER);
        nextTitle.setFont(new Font("Arial", Font.BOLD, 14));
        nextCard.add(nextTitle);

        nextOrderLabel.setBounds(25, 38, contentW - 50, 30);
        nextOrderLabel.setForeground(TEXT_CREAM);
        nextOrderLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        nextCard.add(nextOrderLabel);

        // ==== Orders glass table ====
        JPanel tableCard = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(255, 220, 180, 20));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.setColor(new Color(255, 220, 180, 60));
                g2.setStroke(new BasicStroke(1.2f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 20, 20);
            }
        };
        tableCard.setLayout(new BorderLayout());
        tableCard.setOpaque(false);
        tableCard.setBounds(contentX, 200, contentW, 380);
        bg.add(tableCard);

        tableModel = new DefaultTableModel(
                new String[]{"ID", "Food Item", "Qty", "Priority", "Status"}, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        table = new JTable(tableModel);
        table.setRowHeight(30);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setForeground(TEXT_CREAM);
        table.setBackground(new Color(0, 0, 0, 0));
        table.setOpaque(false);
        table.setGridColor(new Color(255, 220, 180, 25));
        table.setShowGrid(true);
        table.setSelectionBackground(new Color(230, 160, 60, 90));
        table.setSelectionForeground(TEXT_CREAM);
        table.getTableHeader().setReorderingAllowed(false);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        table.getTableHeader().setForeground(TEXT_CREAM);
        table.getTableHeader().setBackground(WOOD_LIGHT);

        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        center.setOpaque(false);
        center.setForeground(TEXT_CREAM);
        for (int i = 0; i < table.getColumnCount(); i++)
            table.getColumnModel().getColumn(i).setCellRenderer(center);

        JScrollPane sp = new JScrollPane(table);
        sp.setOpaque(false);
        sp.getViewport().setOpaque(false);
        sp.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        tableCard.add(sp, BorderLayout.CENTER);

        // ================================================================
        // ================ NEW: STYLED ACTION BUTTONS ====================
        // ================================================================
        // Two rows of action buttons with icons, labels, and grouped styles.
        // Layout: left group (order actions) + right group (view actions)

        // ----- LEFT GROUP: order actions -----
        int leftGroupX = contentX;
        int leftGroupY = 600;
        int btnH = 70;
        int btnGap = 12;

        // Add Order
        JPanel btnAdd = actionButton(
                "➕", "Add Order", "Create new",
                new Color(140, 200, 120),
                new Color(160, 220, 140),
                e -> showAddDialog());
        btnAdd.setBounds(leftGroupX, leftGroupY, 130, btnH);
        bg.add(btnAdd);

        // Process Next (primary — amber)
        JPanel btnProcess = actionButton(
                "👨‍🍳", "Process Next", "From queue",
                ACCENT_AMBER,
                new Color(255, 190, 100),
                e -> processNext());
        btnProcess.setBounds(leftGroupX + 142, leftGroupY, 140, btnH);
        bg.add(btnProcess);

        // Update Status
        JPanel btnUpdate = actionButton(
                "✏️", "Update", "Change status",
                new Color(180, 130, 90),
                new Color(210, 160, 110),
                e -> updateSelected());
        btnUpdate.setBounds(leftGroupX + 294, leftGroupY, 130, btnH);
        bg.add(btnUpdate);

        // Delete
        JPanel btnDelete = actionButton(
                "🗑", "Delete", "Remove order",
                new Color(200, 90, 60),
                new Color(230, 110, 80),
                e -> deleteSelected());
        btnDelete.setBounds(leftGroupX + 436, leftGroupY, 120, btnH);
        bg.add(btnDelete);

        // ----- RIGHT GROUP: view actions -----
        int rightGroupX = contentX + contentW - 290;

        // History
        JPanel btnHistory = actionButton(
                "📜", "History", "Completed",
                new Color(140, 160, 200),
                new Color(170, 190, 230),
                e -> showHistory());
        btnHistory.setBounds(rightGroupX, leftGroupY, 130, btnH);
        bg.add(btnHistory);

        // Refresh
        JPanel btnRefresh = actionButton(
                "🔄", "Refresh", "Reload data",
                new Color(150, 150, 150),
                new Color(180, 180, 180),
                e -> refreshAll());
        btnRefresh.setBounds(rightGroupX + 142, leftGroupY, 140, btnH);
        bg.add(btnRefresh);

        refreshAll();
    }

    // ================================================================
    // ================ ACTION BUTTON FACTORY =========================
    // ================================================================
    /**
     * A big icon + title + subtitle button panel with custom hover and click.
     */
    private JPanel actionButton(String icon, String title, String subtitle,
                                Color baseColor, Color hoverColor,
                                java.awt.event.ActionListener action) {

        JPanel btn = new JPanel(null) {
            private boolean hovered = false;
            private boolean pressed = false;

            {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hovered = true;  repaint(); }
                    @Override public void mouseExited(MouseEvent e)  { hovered = false; repaint(); }
                    @Override public void mousePressed(MouseEvent e) { pressed = true;  repaint(); }
                    @Override public void mouseReleased(MouseEvent e) {
                        pressed = false; repaint();
                        if (action != null) action.actionPerformed(null);
                    }
                });
                setCursor(new Cursor(Cursor.HAND_CURSOR));
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                // Shadow
                g2.setColor(new Color(0, 0, 0, 60));
                g2.fillRoundRect(2, 3, w - 4, h - 4, 18, 18);

                // Base fill
                Color fill;
                if (pressed) {
                    fill = new Color(
                            Math.max(0, baseColor.getRed() - 30),
                            Math.max(0, baseColor.getGreen() - 30),
                            Math.max(0, baseColor.getBlue() - 30),
                            220);
                } else if (hovered) {
                    fill = new Color(hoverColor.getRed(), hoverColor.getGreen(),
                            hoverColor.getBlue(), 210);
                } else {
                    fill = new Color(baseColor.getRed(), baseColor.getGreen(),
                            baseColor.getBlue(), 170);
                }
                g2.setColor(fill);
                g2.fillRoundRect(0, 0, w, h, 18, 18);

                // Subtle top highlight
                g2.setColor(new Color(255, 255, 255, 40));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, 16, 16);

                // Inner glow on hover
                if (hovered) {
                    g2.setColor(new Color(255, 255, 255, 60));
                    g2.setStroke(new BasicStroke(1.5f));
                    g2.drawRoundRect(0, 0, w - 1, h - 1, 18, 18);
                }
            }
        };
        btn.setOpaque(false);
        btn.setLayout(null);

        // Icon
        JLabel ico = new JLabel(icon, SwingConstants.CENTER);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 22));
        ico.setForeground(Color.WHITE);
        ico.setBounds(8, 10, 40, 40);
        ico.setOpaque(false);
        btn.add(ico);

        // Title
        JLabel t = new JLabel(title);
        t.setFont(new Font("Arial", Font.BOLD, 13));
        t.setForeground(Color.WHITE);
        t.setBounds(50, 14, 120, 20);
        btn.add(t);

        // Subtitle
        JLabel s = new JLabel(subtitle);
        s.setFont(new Font("Arial", Font.PLAIN, 10));
        s.setForeground(new Color(255, 255, 255, 200));
        s.setBounds(50, 34, 120, 15);
        btn.add(s);

        return btn;
    }

    // ================================================================
    // ================== NAV ITEM FACTORY ============================
    // ================================================================
    private JPanel makeNavItem(String icon, String label, boolean active) {
        JPanel item = new JPanel(null) {
            private boolean hovered = false;
            {
                addMouseListener(new MouseAdapter() {
                    @Override public void mouseEntered(MouseEvent e) { hovered = true; repaint(); }
                    @Override public void mouseExited(MouseEvent e)  { hovered = false; repaint(); }
                });
                setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                if (active) {
                    g2.setColor(new Color(230, 160, 60, 90));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                    g2.setColor(ACCENT_AMBER);
                    g2.fillRoundRect(0, 8, 4, getHeight() - 16, 4, 4);
                } else if (hovered) {
                    g2.setColor(new Color(255, 220, 180, 40));
                    g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                }
            }
        };
        item.setOpaque(false);

        JLabel ico = new JLabel(icon, SwingConstants.CENTER);
        ico.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
        ico.setBounds(20, 0, 30, 45);
        ico.setForeground(active ? ACCENT_AMBER : TEXT_CREAM);
        item.add(ico);

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Arial", active ? Font.BOLD : Font.PLAIN, 13));
        lbl.setBounds(60, 0, 150, 45);
        lbl.setForeground(active ? TEXT_CREAM : TEXT_WARM);
        item.add(lbl);

        return item;
    }

    // ================================================================
    // ============== EXISTING LOGIC ==================================
    // ================================================================

    private void refreshAll() {
        pq = service.loadPendingHeap();
        Order next = pq.peek();
        nextOrderLabel.setText(next == null
                ? "No pending orders."
                : String.format("#%d — %s x%d (Priority %d)",
                next.getOrderId(), next.getFoodItem(),
                next.getQuantity(), next.getPriority()));

        tableModel.setRowCount(0);
        List<Order> orders = service.getActiveOrders();
        for (Order o : orders) {
            tableModel.addRow(new Object[]{
                    o.getOrderId(), o.getFoodItem(), o.getQuantity(),
                    o.getPriority(), o.getStatus()
            });
        }
    }

    private void showAddDialog() {
        JTextField itemField = new JTextField();
        JTextField qtyField = new JTextField();
        JComboBox<String> prioBox = new JComboBox<>(new String[]{
                "5 — Rush", "4 — VIP", "3 — High", "2 — Normal", "1 — Low"
        });
        Object[] msg = {"Food Item:", itemField, "Quantity:", qtyField, "Priority:", prioBox};
        int r = JOptionPane.showConfirmDialog(this, msg, "Add New Order",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (r != JOptionPane.OK_OPTION) return;
        try {
            String item = itemField.getText().trim();
            int qty = Integer.parseInt(qtyField.getText().trim());
            int prio = 5 - prioBox.getSelectedIndex();
            if (item.isEmpty()) return;
            service.addOrder(item, qty, prio);
            refreshAll();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a number.");
        }
    }

    private void processNext() {
        Order next = pq.extractMax();
        if (next == null) { JOptionPane.showMessageDialog(this, "No pending orders."); return; }
        service.updateStatus(next.getOrderId(), "Preparing");
        refreshAll();
        JOptionPane.showMessageDialog(this,
                "Now preparing Order #" + next.getOrderId() + " (" + next.getFoodItem() + ")");
    }

    private void updateSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select an order first."); return; }
        int id = (int) tableModel.getValueAt(row, 0);
        String current = (String) tableModel.getValueAt(row, 4);
        String[] options = {"Pending", "Preparing", "Ready", "Completed"};
        String choice = (String) JOptionPane.showInputDialog(
                this, "New status:", "Update Order #" + id,
                JOptionPane.QUESTION_MESSAGE, null, options, current);
        if (choice != null) { service.updateStatus(id, choice); refreshAll(); }
    }

    private void deleteSelected() {
        int row = table.getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this, "Select an order first."); return; }
        int id = (int) tableModel.getValueAt(row, 0);
        int c = JOptionPane.showConfirmDialog(this, "Delete Order #" + id + "?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (c == JOptionPane.YES_OPTION) { service.deleteOrder(id); refreshAll(); }
    }

    private void showHistory() {
        List<String[]> rows = service.getHistory();
        String[] cols = {"ID", "Food Item", "Qty", "Priority", "Time"};
        DefaultTableModel model = new DefaultTableModel(cols, 0);
        for (String[] r : rows) model.addRow(r);
        JTable histTable = new JTable(model);
        histTable.setRowHeight(22);
        JScrollPane sp = new JScrollPane(histTable);
        sp.setPreferredSize(new Dimension(620, 320));
        JOptionPane.showMessageDialog(this, sp, "Order History", JOptionPane.PLAIN_MESSAGE);
    }

    private JButton makeMacButton(int x, int y, Color normal, Color hover,
                                  java.awt.event.ActionListener action) {
        JButton btn = new JButton() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : normal);
                g2.fillOval(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        btn.setBounds(x, y, 14, 14);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(action);
        return btn;
    }

    private int clamp(int v) {
        if (v < 0) return 0;
        if (v > 255) return 255;
        return v;
    }
}