public class Order {
    private final int orderId;
    private final String foodItem;
    private final int quantity;
    private final int priority;
    private final String status;

    public Order(int orderId, String foodItem, int quantity, int priority, String status) {
        this.orderId = orderId;
        this.foodItem = foodItem;
        this.quantity = quantity;
        this.priority = priority;
        this.status = status;
    }

    public int getOrderId()     { return orderId; }
    public String getFoodItem() { return foodItem; }
    public int getQuantity()    { return quantity; }
    public int getPriority()    { return priority; }
    public String getStatus()   { return status; }
}