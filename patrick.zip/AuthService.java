public class AuthService {
    private static final String TEMP_USER = "admin";
    private static final String TEMP_PASS = "1234";

    public boolean login(String u, String p) {
        return u.equals(TEMP_USER) && p.equals(TEMP_PASS);
    }
}