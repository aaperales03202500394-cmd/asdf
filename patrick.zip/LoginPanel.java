import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.Random;

public class LoginPanel extends JPanel {

    private final Main.KitchenApp app;
    private final Settings settings;
    private final AuthService auth = new AuthService();

    private final Point dragOffset = new Point();

    // ==== WOODEN THEME ====
    private final Color WOOD_DARK      = new Color(38, 22, 14);
    private final Color WOOD_MID       = new Color(62, 38, 24);
    private final Color WOOD_LIGHT     = new Color(92, 58, 36);
    private final Color WOOD_GRAIN     = new Color(30, 18, 10);
    private final Color CARD_WOOD      = new Color(52, 32, 20);
    private final Color FIELD_WOOD     = new Color(38, 22, 14);
    private final Color TEXT_CREAM     = new Color(245, 232, 210);
    private final Color TEXT_WARM      = new Color(200, 175, 145);
    private final Color ACCENT_AMBER   = new Color(230, 160, 60);
    private final Color BORDER_WOOD    = new Color(90, 60, 40);

    // ==== RIGHT PANEL — WARM AMBER ====
    private final Color AMBER_DARK     = new Color(80, 45, 15);
    private final Color AMBER_MID      = new Color(130, 75, 25);
    private final Color AMBER_LIGHT    = new Color(180, 110, 40);
    private final Color AMBER_BRIGHT   = new Color(220, 150, 70);

    private double logoAngle = 0;

    public LoginPanel(Main.KitchenApp app, Settings settings) {
        this.app = app;
        this.settings = settings;
        setLayout(null);

        final String path = settings.ASSET_PATH;

        // ============ ROOT — FULL WOODEN BACKGROUND ============
        JPanel root = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                GradientPaint base = new GradientPaint(0, 0, WOOD_MID, 0, h, WOOD_DARK);
                g2.setPaint(base);
                g2.fillRect(0, 0, w, h);

                int plankHeight = 60;
                Random plankRand = new Random(99);
                for (int y = 0; y < h; y += plankHeight) {
                    int variation = plankRand.nextInt(20) - 10;
                    Color plankColor = new Color(
                            clamp(WOOD_MID.getRed() + variation),
                            clamp(WOOD_MID.getGreen() + variation),
                            clamp(WOOD_MID.getBlue() + variation),
                            120);
                    g2.setColor(plankColor);
                    g2.fillRect(0, y, w, plankHeight);

                    g2.setColor(new Color(20, 12, 6, 180));
                    g2.drawLine(0, y, w, y);
                }

                Random grainRand = new Random(7);
                g2.setStroke(new BasicStroke(0.8f));
                for (int i = 0; i < 260; i++) {
                    int gy = grainRand.nextInt(h);
                    int gx = grainRand.nextInt(w);
                    int len = 40 + grainRand.nextInt(200);
                    int alpha = 20 + grainRand.nextInt(30);
                    g2.setColor(new Color(
                            WOOD_GRAIN.getRed(),
                            WOOD_GRAIN.getGreen(),
                            WOOD_GRAIN.getBlue(),
                            alpha));

                    Path2D.Double p = new Path2D.Double();
                    p.moveTo(gx, gy);
                    int segments = 4;
                    for (int s = 1; s <= segments; s++) {
                        int nx = gx + (len / segments) * s;
                        int ny = gy + grainRand.nextInt(4) - 2;
                        p.lineTo(nx, ny);
                    }
                    g2.draw(p);
                }

                Random knotRand = new Random(3);
                for (int i = 0; i < 4; i++) {
                    int kx = knotRand.nextInt(w);
                    int ky = knotRand.nextInt(h);
                    int kr = 8 + knotRand.nextInt(15);
                    for (int r = kr; r > 0; r -= 2) {
                        g2.setColor(new Color(
                                WOOD_GRAIN.getRed(),
                                WOOD_GRAIN.getGreen(),
                                WOOD_GRAIN.getBlue(),
                                60));
                        g2.drawOval(kx - r / 2, ky - r / 3, r, (int) (r * 0.7));
                    }
                }

                RadialGradientPaint vignette = new RadialGradientPaint(
                        new Point(w / 2, h / 2),
                        Math.max(w, h) * 0.85f,
                        new float[]{0.3f, 1.0f},
                        new Color[]{new Color(0, 0, 0, 0), new Color(0, 0, 0, 160)}
                );
                g2.setPaint(vignette);
                g2.fillRect(0, 0, w, h);
            }
        };
        root.setBackground(WOOD_DARK);
        add(root);
        root.setBounds(0, 0, 1280, 720);

        // ============ SMALL LEAVES — TOP-LEFT CORNER ============
        JPanel cornerLeaves = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                drawVine(g2, -20, -10,  60, 110, 4);
                drawVine(g2,  20, -20,  95,  80, 3);
                drawVine(g2,  55, -20, 130, 130, 5);
                drawVine(g2, 105, -20,  85,  60, 3);
            }
        };
        cornerLeaves.setOpaque(false);
        cornerLeaves.setBounds(0, 0, 230, 200);
        cornerLeaves.setEnabled(false);
        root.add(cornerLeaves);
        root.setComponentZOrder(cornerLeaves, 0);

        // ============ DRAG WINDOW ============
        root.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) {
                dragOffset.x = e.getX();
                dragOffset.y = e.getY();
            }
        });
        root.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                Point p = app.getLocation();
                app.setLocation(p.x + e.getX() - dragOffset.x,
                        p.y + e.getY() - dragOffset.y);
            }
        });

        // ============ RIGHT SIDE — FLOATING AMBER PANEL ============
        int panelX = 680;
        int panelY = 10;
        int panelW = 590;
        int panelH = 700;

        JPanel artPanel = new JPanel() {
            private final ImageIcon logoIcon = tryLoad(path + "logo.png");
            private Image scaledLogo;

            private final Random iconRand = new Random(123);
            private final String[] kitchenIcons = {
                    "🍳", "🍕", "🥗", "🍔", "🍜", "🥘",
                    "🍱", "🍰", "☕", "🥂", "🍣", "🍩",
                    "🥐", "🍦", "🍤", "🍇"
            };
            private final java.util.List<IconSpot> iconSpots = new java.util.ArrayList<>();
            private final java.util.Map<Integer, Long> twinklingIcons = new java.util.HashMap<>();

            private int hoveredIconIndex = -1;
            private int hoveredMacDot = -1;

            class IconSpot {
                int x, y;
                String emoji;
                int baseAlpha;
                int size;
                IconSpot(int x, int y, String emoji, int baseAlpha, int size) {
                    this.x = x; this.y = y; this.emoji = emoji;
                    this.baseAlpha = baseAlpha; this.size = size;
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                Shape oldClip = g2.getClip();
                RoundRectangle2D panelShape = new RoundRectangle2D.Double(0, 0, w, h, 40, 40);
                g2.setClip(panelShape);

                GradientPaint baseGrad = new GradientPaint(0, 0, AMBER_DARK, w, h, AMBER_LIGHT);
                g2.setPaint(baseGrad);
                g2.fillRect(0, 0, w, h);

                g2.setColor(new Color(AMBER_MID.getRed(), AMBER_MID.getGreen(), AMBER_MID.getBlue(), 120));
                g2.fill(new RoundRectangle2D.Double(-120, -80, 420, 700, 200, 200));

                g2.setColor(new Color(AMBER_BRIGHT.getRed(), AMBER_BRIGHT.getGreen(), AMBER_BRIGHT.getBlue(), 90));
                g2.fillOval(-100, 220, 380, 380);

                g2.setColor(new Color(AMBER_DARK.getRed(), AMBER_DARK.getGreen(), AMBER_DARK.getBlue(), 180));
                g2.fill(new RoundRectangle2D.Double(w - 260, h - 320, 500, 500, 220, 220));

                g2.setColor(new Color(AMBER_MID.getRed(), AMBER_MID.getGreen(), AMBER_MID.getBlue(), 100));
                g2.fillOval(w - 220, 80, 320, 320);

                g2.setColor(new Color(255, 230, 200, 20));
                Path2D.Double sweep = new Path2D.Double();
                sweep.moveTo(w * 0.2, 0);
                sweep.lineTo(w * 0.7, 0);
                sweep.lineTo(w * 0.3, h);
                sweep.lineTo(-w * 0.2, h);
                sweep.closePath();
                g2.fill(sweep);

                if (iconSpots.isEmpty()) {
                    int cols = 4, rows = 5;
                    double cellW = (double) w / cols;
                    double cellH = (double) h / rows;

                    for (int r = 0; r < rows; r++) {
                        for (int c = 0; c < cols; c++) {
                            int jitterX = (int) (iconRand.nextDouble() * cellW * 0.6 - cellW * 0.3);
                            int jitterY = (int) (iconRand.nextDouble() * cellH * 0.6 - cellH * 0.3);
                            int px = (int) (c * cellW + cellW / 2) + jitterX;
                            int py = (int) (r * cellH + cellH / 2) + jitterY;

                            int logoBoxW = (int) (w * 0.55);
                            int logoBoxH = (int) (logoBoxW * 0.6);
                            int logoX = (w - logoBoxW) / 2;
                            int logoY = (h - logoBoxH) / 2;
                            if (px > logoX - 30 && px < logoX + logoBoxW + 30 &&
                                    py > logoY - 30 && py < logoY + logoBoxH + 30) continue;

                            String emoji = kitchenIcons[iconRand.nextInt(kitchenIcons.length)];
                            int alpha = 30 + iconRand.nextInt(50);
                            int size = 22 + iconRand.nextInt(20);
                            iconSpots.add(new IconSpot(px, py, emoji, alpha, size));
                        }
                    }
                }

                if (iconRand.nextInt(50) == 0 && !iconSpots.isEmpty()) {
                    int idx = iconRand.nextInt(iconSpots.size());
                    twinklingIcons.put(idx, System.currentTimeMillis());
                }

                long now = System.currentTimeMillis();

                for (int i = 0; i < iconSpots.size(); i++) {
                    IconSpot s = iconSpots.get(i);
                    int alpha = s.baseAlpha;
                    int drawSize = s.size;

                    Long twinkleStart = twinklingIcons.get(i);
                    if (twinkleStart != null) {
                        long elapsed = now - twinkleStart;
                        if (elapsed < 900) {
                            double t = elapsed / 900.0;
                            int boost = (int) (Math.sin(t * Math.PI) * 120);
                            alpha = Math.min(255, alpha + boost);
                        } else {
                            twinklingIcons.remove(i);
                        }
                    }

                    if (i == hoveredIconIndex) {
                        drawSize = (int) (s.size * 1.4);
                        alpha = Math.min(255, alpha + 150);
                    }

                    g2.setFont(new Font("Segoe UI Emoji", Font.PLAIN, drawSize));
                    g2.setColor(new Color(255, 245, 225, alpha));
                    g2.drawString(s.emoji, s.x, s.y);
                }

                if (logoIcon != null) {
                    if (scaledLogo == null) {
                        int targetW = (int) (w * 0.55);
                        int targetH = (int) (logoIcon.getIconHeight() *
                                ((double) targetW / logoIcon.getIconWidth()));
                        scaledLogo = logoIcon.getImage().getScaledInstance(
                                targetW, targetH, Image.SCALE_SMOOTH);
                    }

                    int logoW = scaledLogo.getWidth(this);
                    int logoH = scaledLogo.getHeight(this);
                    int baseX = (w - logoW) / 2;
                    int baseY = (h - logoH) / 2;
                    int offset = (int) (Math.sin(logoAngle) * 10);

                    for (int i = 8; i > 0; i--) {
                        g2.setColor(new Color(255, 220, 180, 6));
                        g2.fillOval(baseX + logoW / 2 - logoW / 2 - i * 6,
                                baseY + logoH / 2 - logoH / 2 - i * 6 + offset,
                                logoW + i * 12, logoH + i * 12);
                    }

                    g2.drawImage(scaledLogo, baseX, baseY + offset, this);
                } else {
                    g2.setFont(new Font("Serif", Font.BOLD, 60));
                    g2.setColor(new Color(255, 245, 225));
                    String t = "K-Queue";
                    FontMetrics fm = g2.getFontMetrics();
                    int tx = (w - fm.stringWidth(t)) / 2;
                    int ty = h / 2;
                    int offset = (int) (Math.sin(logoAngle) * 10);
                    g2.drawString(t, tx, ty + offset);
                }

                int dotY = 25;
                int dotX = w - 90;

                int ySize = (hoveredMacDot == 0) ? 18 : 14;
                int yOff  = (hoveredMacDot == 0) ? -2 : 0;
                g2.setColor(hoveredMacDot == 0 ? new Color(255, 189, 46) : new Color(230, 160, 35));
                g2.fillOval(dotX + yOff, dotY + yOff, ySize, ySize);

                int gSize = (hoveredMacDot == 1) ? 18 : 14;
                int gOff  = (hoveredMacDot == 1) ? -2 : 0;
                g2.setColor(hoveredMacDot == 1 ? new Color(40, 200, 64) : new Color(34, 175, 52));
                g2.fillOval(dotX + 26 + gOff, dotY + gOff, gSize, gSize);

                int rSize = (hoveredMacDot == 2) ? 18 : 14;
                int rOff  = (hoveredMacDot == 2) ? -2 : 0;
                g2.setColor(hoveredMacDot == 2 ? new Color(255, 95, 87) : new Color(255, 74, 74));
                g2.fillOval(dotX + 52 + rOff, dotY + rOff, rSize, rSize);

                g2.setClip(oldClip);

                g2.setColor(new Color(0, 0, 0, 180));
                g2.setStroke(new BasicStroke(2f));
                g2.drawRoundRect(1, 1, w - 3, h - 3, 40, 40);

                g2.setColor(new Color(255, 220, 180, 60));
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(3, 3, w - 7, h - 7, 36, 36);
            }

            {
                addMouseMotionListener(new MouseMotionAdapter() {
                    @Override
                    public void mouseMoved(MouseEvent e) {
                        int mx = e.getX();
                        int my = e.getY();

                        int newHover = -1;
                        for (int i = 0; i < iconSpots.size(); i++) {
                            IconSpot s = iconSpots.get(i);
                            Rectangle r = new Rectangle(s.x - 4, s.y - s.size + 8, s.size + 8, s.size + 8);
                            if (r.contains(mx, my)) { newHover = i; break; }
                        }
                        if (newHover != hoveredIconIndex) {
                            hoveredIconIndex = newHover;
                            repaint();
                        }

                        int w = getWidth();
                        int dotY = 25;
                        int dotX = w - 90;
                        int newDot = -1;
                        if (new Rectangle(dotX, dotY, 16, 16).contains(mx, my)) newDot = 0;
                        else if (new Rectangle(dotX + 26, dotY, 16, 16).contains(mx, my)) newDot = 1;
                        else if (new Rectangle(dotX + 52, dotY, 16, 16).contains(mx, my)) newDot = 2;
                        if (newDot != hoveredMacDot) {
                            hoveredMacDot = newDot;
                            setCursor(newDot >= 0 ? new Cursor(Cursor.HAND_CURSOR) : Cursor.getDefaultCursor());
                            repaint();
                        }
                    }
                });

                addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseExited(MouseEvent e) {
                        hoveredIconIndex = -1;
                        hoveredMacDot = -1;
                        repaint();
                    }

                    @Override
                    public void mouseClicked(MouseEvent e) {
                        int w = getWidth();
                        int dotY = 25;
                        int dotX = w - 90;
                        int mx = e.getX(), my = e.getY();

                        if (new Rectangle(dotX, dotY, 18, 18).contains(mx, my)) {
                            app.setExtendedState(JFrame.ICONIFIED);
                        } else if (new Rectangle(dotX + 26, dotY, 18, 18).contains(mx, my)) {
                            Toolkit.getDefaultToolkit().beep();
                        } else if (new Rectangle(dotX + 52, dotY, 18, 18).contains(mx, my)) {
                            System.exit(0);
                        }
                    }
                });
            }
        };
        artPanel.setOpaque(false);
        artPanel.setBounds(panelX, panelY, panelW, panelH);
        root.add(artPanel);

        JPanel panelShadow = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                for (int i = 20; i > 0; i--) {
                    g2.setColor(new Color(0, 0, 0, 6));
                    g2.fillRoundRect(i, i, getWidth() - i * 2, getHeight() - i * 2, 40 + i, 40 + i);
                }
            }
        };
        panelShadow.setOpaque(false);
        panelShadow.setBounds(panelX - 5, panelY - 5, panelW + 30, panelH + 30);
        panelShadow.setEnabled(false);
        root.add(panelShadow);
        root.setComponentZOrder(panelShadow, 1);
        root.setComponentZOrder(artPanel, 0);

        Timer logoTimer = new Timer(16, e -> {
            logoAngle += 0.03;
            if (logoAngle > Math.PI * 2) logoAngle -= Math.PI * 2;
            artPanel.repaint();
        });
        logoTimer.start();

        // ============ LEFT SIDE — LOGIN CARD ============
        JPanel loginCard = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                for (int i = 15; i > 0; i--) {
                    g2.setColor(new Color(0, 0, 0, 8));
                    g2.fillRoundRect(i, i, getWidth() - i * 2, getHeight() - i * 2, 30 + i, 30 + i);
                }

                g2.setColor(new Color(0, 0, 0, 160));
                g2.fillRoundRect(8, 8, getWidth() - 8, getHeight() - 8, 30, 30);

                g2.setColor(CARD_WOOD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);

                Random grainRand = new Random(11);
                g2.setStroke(new BasicStroke(0.6f));
                for (int i = 0; i < 40; i++) {
                    int gy = grainRand.nextInt(getHeight());
                    int gx = grainRand.nextInt(getWidth());
                    int len = 20 + grainRand.nextInt(80);
                    g2.setColor(new Color(20, 12, 6, 25));
                    g2.drawLine(gx, gy, gx + len, gy + grainRand.nextInt(3) - 1);
                }

                g2.setColor(new Color(255, 220, 180, 15));
                g2.setStroke(new BasicStroke(1.5f));
                g2.drawRoundRect(1, 1, getWidth() - 3, getHeight() - 3, 28, 28);

                g2.setColor(BORDER_WOOD);
                g2.setStroke(new BasicStroke(1f));
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 30, 30);
            }
        };
        loginCard.setLayout(null);
        loginCard.setOpaque(false);
        loginCard.setBounds(120, 100, 500, 540);
        root.add(loginCard);

        JLabel brand = new JLabel("K-Queue", SwingConstants.CENTER);
        brand.setFont(new Font("Serif", Font.BOLD, 42));
        brand.setForeground(TEXT_CREAM);
        brand.setBounds(50, 35, 400, 60);
        loginCard.add(brand);

        JLabel subtitle = new JLabel("Kitchen Food Order Management System", SwingConstants.CENTER);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        subtitle.setForeground(TEXT_WARM);
        subtitle.setBounds(50, 95, 400, 20);
        loginCard.add(subtitle);

        JPanel userPanel = makeIconField("👤", "Username", false);
        userPanel.setBounds(60, 165, 380, 45);
        loginCard.add(userPanel);
        JTextField userField = (JTextField) userPanel.getClientProperty("field");

        JPanel passPanel = makeIconField("🔒", "Password", true);
        passPanel.setBounds(60, 230, 380, 45);
        loginCard.add(passPanel);
        JPasswordField passField = (JPasswordField) passPanel.getClientProperty("field");

        JLabel eyeLabel = new JLabel("👁");
        eyeLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16));
        eyeLabel.setForeground(TEXT_WARM);
        eyeLabel.setBounds(410, 240, 30, 22);
        eyeLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        loginCard.add(eyeLabel);
        final boolean[] passVisible = { false };
        eyeLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                passVisible[0] = !passVisible[0];
                if (passVisible[0]) passField.setEchoChar((char) 0);
                else passField.setEchoChar('•');
            }
        });

        JCheckBox remember = new JCheckBox("Remember Me");
        remember.setFont(new Font("Arial", Font.PLAIN, 12));
        remember.setForeground(TEXT_WARM);
        remember.setBackground(CARD_WOOD);
        remember.setFocusPainted(false);
        remember.setBounds(60, 295, 130, 22);
        loginCard.add(remember);

        JLabel forgot = new JLabel("Forgot Password?");
        forgot.setFont(new Font("Arial", Font.PLAIN, 12));
        forgot.setForeground(TEXT_WARM);
        forgot.setBounds(320, 295, 140, 22);
        forgot.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgot.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { forgot.setForeground(ACCENT_AMBER); }
            public void mouseExited(MouseEvent e)  { forgot.setForeground(TEXT_WARM); }
        });
        loginCard.add(forgot);

        JLabel errorLabel = new JLabel("");
        errorLabel.setFont(new Font("Arial", Font.BOLD, 12));
        errorLabel.setForeground(new Color(255, 130, 100));
        errorLabel.setBounds(60, 325, 380, 20);
        loginCard.add(errorLabel);

        JButton loginBtn = new JButton("Log In") {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                Color c = ACCENT_AMBER;
                if (getModel().isPressed())        c = new Color(190, 130, 40);
                else if (getModel().isRollover())  c = new Color(255, 180, 80);

                if (getModel().isRollover()) {
                    g2.setColor(new Color(255, 200, 100, 80));
                    g2.fillRoundRect(-4, -4, getWidth() + 8, getHeight() + 8, 28, 28);
                }

                g2.setColor(c);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        loginBtn.setBounds(60, 360, 380, 50);
        loginBtn.setFont(new Font("Arial", Font.BOLD, 15));
        loginBtn.setForeground(new Color(40, 22, 10));
        loginBtn.setBorder(BorderFactory.createEmptyBorder());
        loginBtn.setContentAreaFilled(false);
        loginBtn.setFocusPainted(false);
        loginBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        loginBtn.addActionListener(e -> {
            errorLabel.setText("");
            String u = userField.getText().trim();
            String p = new String(passField.getPassword()).trim();
            if (u.isEmpty() || p.isEmpty()) {
                errorLabel.setText("Fields cannot be empty!");
                return;
            }
            if (auth.login(u, p)) {
                logoTimer.stop();
                app.showDashboard(u);
            } else {
                errorLabel.setText("Invalid credentials! Access denied.");
            }
        });
        loginCard.add(loginBtn);

        JLabel hint = new JLabel("Default: admin / 1234", SwingConstants.CENTER);
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        hint.setForeground(new Color(140, 110, 80));
        hint.setBounds(60, 425, 380, 22);
        loginCard.add(hint);

        SwingUtilities.invokeLater(() -> {
            if (getRootPane() != null) {
                getRootPane().setDefaultButton(loginBtn);
            }
        });
    }

    // ============ LEAVES DRAWING ============

    private void drawVine(Graphics2D g2, int startX, int startY, int endX, int endY, int leafCount) {
        Path2D.Double vine = new Path2D.Double();
        vine.moveTo(startX, startY);
        double cp1x = startX + (endX - startX) * 0.3;
        double cp1y = startY + (endY - startY) * 0.7;
        double cp2x = startX + (endX - startX) * 0.7;
        double cp2y = startY + (endY - startY) * 0.4;
        vine.curveTo(cp1x, cp1y, cp2x, cp2y, endX, endY);

        g2.setColor(new Color(45, 75, 40));
        g2.setStroke(new BasicStroke(2.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.draw(vine);

        g2.setColor(new Color(70, 105, 60, 180));
        g2.setStroke(new BasicStroke(1f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g2.draw(vine);

        PathIterator it = vine.getPathIterator(null, 1.0);
        double[] coords = new double[6];
        java.util.List<Point> points = new java.util.ArrayList<>();
        while (!it.isDone()) {
            int type = it.currentSegment(coords);
            if (type == PathIterator.SEG_MOVETO || type == PathIterator.SEG_LINETO) {
                points.add(new Point((int) coords[0], (int) coords[1]));
            }
            it.next();
        }

        if (points.size() < 2) return;

        Random leafRand = new Random(startX * 31L + endX);
        for (int i = 1; i <= leafCount && i < points.size(); i++) {
            int idx = (points.size() - 1) * i / (leafCount + 1);
            Point p = points.get(idx);

            double tilt = leafRand.nextDouble() * Math.PI * 0.8 - Math.PI * 0.4;
            int side = (i % 2 == 0) ? 1 : -1;
            double angle = tilt + (side * Math.PI / 4);

            int leafLen = 18 + leafRand.nextInt(10);
            int leafW = (int) (leafLen * 0.55);

            drawLeaf(g2, p.x, p.y, angle, leafLen, leafW,
                    new Color(60, 110, 50),
                    new Color(130, 180, 100));
        }
    }

    private void drawLeaf(Graphics2D g2, int x, int y, double angle,
                          int length, int width, Color darkGreen, Color lightGreen) {
        AffineTransform old = g2.getTransform();
        g2.translate(x, y);
        g2.rotate(angle);

        Path2D.Double leaf = new Path2D.Double();
        leaf.moveTo(0, 0);
        leaf.curveTo(width / 2.0, -length / 3.0, width / 2.0, -length * 2.0 / 3.0, 0, -length);
        leaf.curveTo(-width / 2.0, -length * 2.0 / 3.0, -width / 2.0, -length / 3.0, 0, 0);
        leaf.closePath();

        GradientPaint gp = new GradientPaint(0, 0, darkGreen, 0, -length, lightGreen);
        g2.setPaint(gp);
        g2.fill(leaf);

        g2.setColor(new Color(30, 60, 25));
        g2.setStroke(new BasicStroke(0.8f));
        g2.draw(leaf);

        g2.setColor(new Color(30, 60, 25, 150));
        g2.setStroke(new BasicStroke(0.6f));
        g2.drawLine(0, 0, 0, -length);

        g2.setStroke(new BasicStroke(0.5f));
        for (int i = 1; i <= 3; i++) {
            int vy = -length * i / 4;
            int vLen = (int) (width / 2.0 * 0.8);
            g2.drawLine(0, vy, vLen, vy - 2);
            g2.drawLine(0, vy, -vLen, vy - 2);
        }

        g2.setTransform(old);
    }

    private int clamp(int v) {
        if (v < 0) return 0;
        if (v > 255) return 255;
        return v;
    }

    private JPanel makeIconField(String icon, String placeholder, boolean isPassword) {
        final JTextField field = isPassword ? new JPasswordField() : new JTextField();

        field.setOpaque(false);
        field.setBorder(null);
        field.setFont(new Font("Arial", Font.PLAIN, 13));
        field.setForeground(TEXT_CREAM);
        field.setCaretColor(ACCENT_AMBER);
        if (isPassword) ((JPasswordField) field).setEchoChar('•');

        JPanel container = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                g2.setColor(FIELD_WOOD);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 22, 22);

                if (field.isFocusOwner()) {
                    g2.setColor(ACCENT_AMBER);
                    g2.setStroke(new BasicStroke(1.5f));
                } else {
                    g2.setColor(BORDER_WOOD);
                    g2.setStroke(new BasicStroke(1f));
                }
                g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 22, 22);
                g2.dispose();
            }
        };
        container.setLayout(null);
        container.setOpaque(false);

        field.addFocusListener(new FocusAdapter() {
            @Override public void focusGained(FocusEvent e) { container.repaint(); }
            @Override public void focusLost(FocusEvent e)   { container.repaint(); }
        });

        JLabel iconLabel = new JLabel(icon, SwingConstants.CENTER);
        iconLabel.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 14));
        iconLabel.setForeground(ACCENT_AMBER);
        iconLabel.setBounds(10, 0, 30, 45);
        container.add(iconLabel);

        field.setBounds(45, 12, 300, 20);

        final String ph = placeholder;
        field.setForeground(TEXT_WARM);
        field.setText(ph);
        field.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (field.getText().equals(ph) && field.getForeground().equals(TEXT_WARM)) {
                    field.setText("");
                    field.setForeground(TEXT_CREAM);
                }
            }
            @Override
            public void focusLost(FocusEvent e) {
                if (field.getText().isEmpty()) {
                    field.setForeground(TEXT_WARM);
                    field.setText(ph);
                }
            }
        });

        container.add(field);
        container.putClientProperty("field", field);
        return container;
    }

    private ImageIcon tryLoad(String path) {
        java.io.File f = new java.io.File(path);
        return f.exists() ? new ImageIcon(path) : null;
    }
}