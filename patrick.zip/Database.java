import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Database {

    private final static String ROOT_URL = "jdbc:mysql://localhost:3306/?allowMultiQueries=true";
    private final static String URL      = "jdbc:mysql://localhost:3306/kitchen_db";
    private final static String USER     = "root";
    private final static String PASSWORD = "";

    public static void initialize() {
        String sql = """
                CREATE DATABASE IF NOT EXISTS kitchen_db;
                USE kitchen_db;
                CREATE TABLE IF NOT EXISTS orders (
                    order_id INT AUTO_INCREMENT PRIMARY KEY,
                    food_item VARCHAR(100),
                    quantity INT,
                    priority INT,
                    status VARCHAR(30) DEFAULT 'Pending',
                    order_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                """;
        try (Connection conn = DriverManager.getConnection(ROOT_URL, USER, PASSWORD);
             Statement st = conn.createStatement()) {
            st.execute(sql);
            System.out.println("✅ Database & table ready.");
        } catch (SQLException ex) {
            printError(ex);
        }
    }

    public static Connection getConnection() {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException ex) {
            printError(ex);
            return null;
        }
    }

    private static void printError(SQLException ex) {
        System.out.println("❌ DB Error: " + ex.getMessage());
    }
}