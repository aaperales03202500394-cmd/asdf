import javax.swing.*;
import java.awt.*;
import java.awt.geom.AffineTransform;
import java.util.ArrayList;
import java.util.Random;

public class ConfettiBurst {

    public static class Particle {
        double x, y, vx, vy;
        float alpha = 1f;
        Color color;
        int size;
        double rotation = 0;
        double rotationSpeed;

        Particle(int originX, int originY, Random rand) {
            this.x = originX;
            this.y = originY;
            double angle = rand.nextDouble() * 2 * Math.PI;
            double speed = 4 + rand.nextDouble() * 8;
            this.vx = Math.cos(angle) * speed;
            this.vy = Math.sin(angle) * speed - 3;

            Color[] palette = {
                    new Color(230, 160, 60),
                    new Color(255, 200, 100),
                    new Color(200, 90, 60),
                    new Color(140, 200, 120),
                    new Color(245, 232, 210),
                    new Color(180, 110, 40),
                    new Color(255, 240, 200)
            };
            this.color = palette[rand.nextInt(palette.length)];
            this.size = 4 + rand.nextInt(5);
            this.rotationSpeed = (rand.nextDouble() - 0.5) * 0.4;
        }

        void update() {
            x += vx;
            y += vy;
            vy += 0.35;
            vx *= 0.99;
            rotation += rotationSpeed;
            alpha -= 0.012f;
            if (alpha < 0) alpha = 0;
        }
    }

    /**
     * Plays a confetti burst on the given layered pane,
     * then runs the onDone callback when finished.
     */
    public static void play(JLayeredPane layer, int originX, int originY, Runnable onDone) {
        // 1) Create the overlay panel FIRST (must be effectively final for lambdas)
        final JPanel overlay = new JPanel(null) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                // The particle list is captured via the outer scope; we access
                // it through the `particles` field below by re-fetching it.
                ArrayList<Particle> ps = (ArrayList<Particle>) getClientProperty("particles");
                if (ps == null) return;

                for (Particle p : ps) {
                    g2.setColor(new Color(p.color.getRed(), p.color.getGreen(),
                            p.color.getBlue(), (int) (p.alpha * 255)));
                    int cx = (int) p.x;
                    int cy = (int) p.y;
                    int s = p.size;

                    AffineTransform old = g2.getTransform();
                    g2.rotate(p.rotation, cx, cy);
                    g2.fillRect(cx - s / 2, cy - s / 2, s, s);
                    g2.setTransform(old);
                }
            }

            // So the overlay doesn't block clicks elsewhere
            @Override
            public boolean contains(int x, int y) { return false; }
        };

        overlay.setOpaque(false);
        overlay.setBounds(0, 0, layer.getWidth(), layer.getHeight());

        // 2) Create particles
        ArrayList<Particle> particles = new ArrayList<>();
        Random rand = new Random();
        for (int i = 0; i < 180; i++) {
            particles.add(new Particle(originX, originY, rand));
        }

        // 3) Give the overlay access to the particle list
        overlay.putClientProperty("particles", particles);

        // 4) Add overlay to the top layer
        layer.add(overlay, JLayeredPane.POPUP_LAYER);
        layer.repaint();

        // 5) Animation loop
        Timer timer = new Timer(16, null);
        timer.addActionListener(e -> {
            for (Particle p : particles) p.update();
            particles.removeIf(p -> p.alpha <= 0);
            overlay.repaint();

            if (particles.isEmpty()) {
                timer.stop();
                layer.remove(overlay);
                layer.repaint();
                if (onDone != null) onDone.run();
            }
        });
        timer.start();
    }
}