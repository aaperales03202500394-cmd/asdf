import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderService {

    public MaxHeap loadPendingHeap() {
        MaxHeap pq = new MaxHeap();
        String sql = "SELECT * FROM orders WHERE status = 'Pending'";
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) pq.insert(mapRow(rs));
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
        return pq;
    }

    public void addOrder(String item, int qty, int prio) {
        String sql = "INSERT INTO orders (food_item, quantity, priority, status) VALUES (?, ?, ?, 'Pending')";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, item); ps.setInt(2, qty); ps.setInt(3, prio);
            ps.executeUpdate();
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
    }

    public List<Order> getActiveOrders() {
        List<Order> list = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE status != 'Completed' ORDER BY priority DESC";
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(mapRow(rs));
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
        return list;
    }

    public void updateStatus(int id, String status) {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status); ps.setInt(2, id);
            ps.executeUpdate();
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
    }

    public void deleteOrder(int id) {
        String sql = "DELETE FROM orders WHERE order_id = ?";
        try (Connection conn = Database.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
    }

    public List<String[]> getHistory() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE status = 'Completed' ORDER BY order_time DESC";
        try (Connection conn = Database.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new String[]{
                        String.valueOf(rs.getInt("order_id")),
                        rs.getString("food_item"),
                        String.valueOf(rs.getInt("quantity")),
                        String.valueOf(rs.getInt("priority")),
                        rs.getTimestamp("order_time").toString()
                });
            }
        } catch (SQLException e) { System.out.println("DB Error: " + e.getMessage()); }
        return list;
    }

    private Order mapRow(ResultSet rs) throws SQLException {
        return new Order(rs.getInt("order_id"), rs.getString("food_item"),
                rs.getInt("quantity"), rs.getInt("priority"), rs.getString("status"));
    }
}