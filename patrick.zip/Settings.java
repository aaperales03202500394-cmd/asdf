import java.io.File;

public class Settings {

    public final String ASSET_PATH;

    public Settings() {
        // Try multiple locations so it works no matter where you run from
        String[] candidates = {
                "assets/",                                       // run from src/
                "src/assets/",                                   // run from project root
                System.getProperty("user.dir") + "/assets/",     // absolute: project root
                System.getProperty("user.dir") + "/src/assets/"  // absolute: src/
        };

        String found = "assets/"; // fallback
        for (String c : candidates) {
            File f = new File(c);
            if (f.exists() && f.isDirectory()) {
                found = c;
                break;
            }
        }

        this.ASSET_PATH = found;
        System.out.println("📁 Asset path: " + new File(found).getAbsolutePath());
    }
}