import java.util.ArrayList;
import java.util.Collections;

public class MaxHeap {
    private final ArrayList<Order> heap = new ArrayList<>();

    public void insert(Order o) {
        heap.add(o);
        bubbleUp(heap.size() - 1);
    }

    public Order extractMax() {
        if (heap.isEmpty()) return null;
        Order max = heap.get(0);
        Order last = heap.remove(heap.size() - 1);
        if (!heap.isEmpty()) {
            heap.set(0, last);
            bubbleDown(0);
        }
        return max;
    }

    public Order peek() { return heap.isEmpty() ? null : heap.get(0); }
    public boolean isEmpty() { return heap.isEmpty(); }

    private void bubbleUp(int i) {
        while (i > 0) {
            int parent = (i - 1) / 2;
            if (heap.get(i).getPriority() > heap.get(parent).getPriority()) {
                Collections.swap(heap, i, parent);
                i = parent;
            } else break;
        }
    }

    private void bubbleDown(int i) {
        int size = heap.size();
        while (true) {
            int left = 2 * i + 1, right = 2 * i + 2, largest = i;
            if (left < size && heap.get(left).getPriority() > heap.get(largest).getPriority())
                largest = left;
            if (right < size && heap.get(right).getPriority() > heap.get(largest).getPriority())
                largest = right;
            if (largest != i) {
                Collections.swap(heap, i, largest);
                i = largest;
            } else break;
        }
    }
}